.. _acknowledgements:

================
Acknowledgements
================
DEIMoS is a product of efforts from numerous individuals, without whom this project would not be possible.
All listings are alphabetical.

Development Lead
----------------
- Sean Colby

Developers
----------
- Jessica Bade
- Christine Chang
- Marjolein Oostrom

Subject Matter Experts
----------------------
- Aivett Bilbao-Peña
- Yehia Ibrahim
- Tom Metz
- Jamie Nuñez
- Dick Smith

Experimentalists
----------------
- Kent Bloodsworth
- Danny Orton

Key Users
---------
- Madison Blumer
- Rachel Richardson

Contributors
------------
- None so far! Please see the :ref:`contributing` section.
