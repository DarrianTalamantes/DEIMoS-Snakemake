=============
deconvolution
=============

.. automodule:: deimos.deconvolution
	:members:
	:private-members:
	:undoc-members:
