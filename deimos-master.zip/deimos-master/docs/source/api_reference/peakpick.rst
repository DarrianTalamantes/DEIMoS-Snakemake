========
peakpick
========

.. automodule:: deimos.peakpick
	:members:
	:private-members:
	:undoc-members:
