======
subset
======

.. automodule:: deimos.subset
	:members:
	:private-members:
	:undoc-members:
