========
isotopes
========

.. automodule:: deimos.isotopes
	:members:
	:private-members:
	:undoc-members:
