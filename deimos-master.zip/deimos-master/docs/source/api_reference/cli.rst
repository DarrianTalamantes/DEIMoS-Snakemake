===
cli
===

.. automodule:: deimos.cli
	:members:
	:private-members:
	:undoc-members:
