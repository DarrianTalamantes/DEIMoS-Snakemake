=====
utils
=====

.. automodule:: deimos.utils
	:members:
	:private-members:
	:undoc-members:
